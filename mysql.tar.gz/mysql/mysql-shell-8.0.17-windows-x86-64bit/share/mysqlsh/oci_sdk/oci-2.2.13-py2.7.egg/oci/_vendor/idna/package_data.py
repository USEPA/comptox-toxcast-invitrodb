# coding: utf-8
# Modified Work: Copyright (c) 2018, 2019, Oracle and/or its affiliates. All rights reserved.
# Copyright (c) 2013-2018, Kim Davies. All rights reserved.

__version__ = '2.8'

