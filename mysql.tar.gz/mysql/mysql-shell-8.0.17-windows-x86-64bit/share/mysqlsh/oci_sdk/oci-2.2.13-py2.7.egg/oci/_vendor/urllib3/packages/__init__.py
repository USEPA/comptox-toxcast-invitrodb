# coding: utf-8
# Modified Work: Copyright (c) 2018, 2019, Oracle and/or its affiliates. All rights reserved.
# Copyright 2008-2016 Andrey Petrov and contributors

from __future__ import absolute_import

from . import ssl_match_hostname

__all__ = ('ssl_match_hostname', )
